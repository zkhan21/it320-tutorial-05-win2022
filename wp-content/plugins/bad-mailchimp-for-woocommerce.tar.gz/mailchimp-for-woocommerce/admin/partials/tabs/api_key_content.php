<div class="box">
    <img width=100% src="<?php echo plugin_dir_url( __FILE__ ) . "images/Screenshot_sync.png"; ?>"/>
</div>