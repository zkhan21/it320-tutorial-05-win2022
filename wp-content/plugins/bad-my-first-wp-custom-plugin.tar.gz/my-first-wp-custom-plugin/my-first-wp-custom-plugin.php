<?php
   /*
   Plugin Name: My First WP Custom Plugin GUTENBERG COMAPTIBLE (No ECHO)
   Description: a very basic HTML table output WP custom plugin
   Version: 5.0
   Author: Michael X. Chase
   File: my_first_wp_custum_plugin.php
   SQL Import File: n/a
   Folder to create: my-first-wp-custom-plugin
   Short code: [my-first-wp-plugin-shortcode]
   License: GPL2
   */
   
  add_shortcode( 'my-first-wp-plugin-shortcode', 'my_first_wp_plugin_entry_point' );

function my_first_wp_plugin_entry_point( $attributes ) {
	
	global $wpdb;
	
	$output2 = null;
    $retval=null;
    #exec('whoami', $output2, $retval);
    #exec('pwd', $output2, $retval);
    exec('ls', $output2, $retval);
    #echo "Returned with status $retval and output:\n";
	
	$output = "";

	$output .= "<table border=\"1\">";
	
	$output .=  "<tr>" . "<td>"  . "My" . "</td>" . "</tr>"
		. "<tr>" . "<td>" . "First"     . "</td>" . "</tr>"
		. "<tr>" . "<td>" . "Custom WP" . "</td>" . "</tr>"
		. "<tr>" . "<td>" . "Plugin"    . "</td>" . "</tr>"
		. "<tr>" . "<td>" . "$retval"   . "</td>" . "</tr>";

	       foreach ($output2 as $value) {
             $output .=  "<tr>" . "<td>" . "$value"   . "</td>" . "</td>";
            }
            
  
        
	$output .=  "</tr>";

	$output .= "</table>";
	
	return $output;
}
?>