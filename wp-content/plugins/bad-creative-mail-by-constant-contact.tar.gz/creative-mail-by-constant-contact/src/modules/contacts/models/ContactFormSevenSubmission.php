<?php


namespace CreativeMail\Modules\Contacts\Models;

use WPCF7_Submission;

class ContactFormSevenSubmission extends WPCF7_Submission
{
  
}