<?php

namespace CreativeMail\Constants;

class EnvironmentNames
{
    const DEVELOPMENT = 'DEVELOP';
    const QA = 'QA';
    const PRODUCTION = 'PRODUCTION';
}
